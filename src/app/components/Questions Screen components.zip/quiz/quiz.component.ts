import { Router } from '@angular/router';
import { Component, OnInit, Input, NgZone } from '@angular/core';
import { Question } from './../../model/Questions';
import { UserAnswer } from './../../model/UserAnswer';
import { QuizService } from './../../components/quiz/quiz.service';
import { FormGroup, FormControl } from "@angular/forms";

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

 constructor(
      private router: Router,
      private ngZone: NgZone,
	  private quizService: QuizService
    ) {}

   index =  0;
    size = 1;
    count = 1;
	test:string="";
	userAnswerID = "";
	userName ="";
	quizNumber =0;
	questionID = 0;
	flagged = false;
	array:any=[];
	
	quizForm: FormGroup;
	disableBackButton:boolean=false;
	disableNextButton:boolean=true;

questions:any = [];
//questions:Question = new Question(null);


//@Input('userAnswerID') userAnsID: String = "";
//name = this.userAnsID;

//quizes: any[];
//  questions: new Question()[];
  
  
  

    ngOnInit() {
   // this.questions = this.quizService.getAll();
    this.loadQuestions();
	this.quizForm = new FormGroup({
	optionSelected : new FormControl()
      })
  }

  loadQuestions() {
    this.quizService.getQuizQuestions().subscribe(res => {
      this.questions = res;
        
    });
	 
    this.questions.forEach((question) => { 
		question.options.forEach((option) => { option.checked = ""; });

	  });
	  
  } //end of loadQuestion()
  
  
   get questionOneByeOne() {
    return (this.questions) ?
      this.questions.slice(this.index, this.index + this.count) : [];
  }
  
  
  
  moveQuestion(index, size) {
    this.index = index;
	this.size=size
	console.log("this.size"+ this.size);
	this.disableBackButton=false;
	this.disableNextButton=true
	if (this.index >= 1) {
		this.disableBackButton=true;
	} 
	
	if (this.index >= this.size-1) {
		this.disableNextButton=false;
	} 
  }

  
  
  moveBack(index) {
    this.index = index;
  }

  moveNext(index) {
    this.index = index;

	 
	  /** this.quizService.saveAnswer(this.employeeForm.value).subscribe(
        (res) => {
          console.log('Answer saved!')
          
        }, (error) => {
          console.log(error);
        });
		**/
		console.log("quizForm.optionSelected",this.quizForm.value );
		
  }

  
    onSelect(question: Question, selectedOption: Number, checked) {
		if (question.questionType === "MultiSelect") {
			/**
			//console.log("selectedOption", selectedOption);
			  question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";}  });
			} else if (question.questionType === "SingleSelect") {
			
			//console.log("selectedOption", selectedOption);
			  question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";} else {i.checked = "";} });
			}**/
			
			//console.log("checked *** ", question.options[2].option.checked);
			  question.options.forEach((i) => { 
				  if (i.optionID === selectedOption && checked === true) {i.checked = "checked";
				  }  
				  if (i.optionID === selectedOption && checked === false) {i.checked = "Unchecked";
				  }  
			  });
		  }
		  
		  	if (question.questionType === "SingleSelect") {
			/**
			//console.log("selectedOption", selectedOption);
			  question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";}  });
			} else if (question.questionType === "SingleSelect") {
			
			//console.log("selectedOption", selectedOption);
			  question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";} else {i.checked = "";} });
			}**/
			
			//console.log("checked *** ", question.options[2].option.checked);
			  question.options.forEach((i) => { 
				  if (i.optionID === selectedOption && checked === true) {i.checked = "checked";
				  }  else {i.checked = "";}
			  });
		  }
   }
   
 /**  
   onSelect1(questionID: Number, selectedOption: Number, checked) {
		//if (question.questionType === "MultiSelect") {
		
		//console.log("selectedOption", selectedOption);
		  //question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";}  });
		//} else if (question.questionType === "SingleSelect") {
		
		//console.log("selectedOption", selectedOption);
		  //question.options.forEach((i) => { if (i.optionID === selectedOption) {i.checked = "checked";} else {i.checked = "";} });
		//}
		console.log("checked inside select1 ***", checked);
		
		this.questions.forEach((question) => { 
		if(question.questionID === questionID) {
			question.options.forEach((i) => { 
			  if (i.optionID === selectedOption && checked === true) {i.checked = "checked";
			  console.log("inside true loop ***",selectedOption,"----", checked);
			  }  
			  if (i.optionID === selectedOption && checked === false) {i.checked = "Unchecked";
			  console.log("inside false loop ***",selectedOption,"----", checked);
			  }  
			  console.log("i.checked ",i.checked);
			  });
		}
	  });
		//console.log("selectedOption", selectedOption);
   }
 **/   
 
 
 
  submitAnswers() {
  let userAnswer = new UserAnswer(null,null,null,null,null);
  
  this.userName="Rajesh";
  this.quizNumber = 1;
  this.questions.forEach((question) => { 
   this.flagged = false; 
		 
		 
	this.questionID = question.questionID;
	this.userAnswerID ="";
	question.options.forEach((option) => { 
	if (option.checked === "checked") 
		this.userAnswerID = this.userAnswerID +","+option.optionID;
	})
	
	this.array = this.userAnswerID.split(',')
	//console.log("this.userAnswerID[0]   ",this.array[0] );
	
	this.userAnswerID = (this.userAnswerID.length && this.userAnswerID[0] == ',') ? this.userAnswerID.slice(1) : this.userAnswerID;
	
	userAnswer.userAnswerID = this.userAnswerID ;
	
    userAnswer = new UserAnswer(this.userName,this.quizNumber, this.questionID, this.userAnswerID, this.flagged );
	
	let data = JSON.stringify( userAnswer );
		 
		 this.quizService.saveAnswer(data).subscribe(
        (res) => {
          console.log('Answer successfully saved!');
		  //TODO this should redirect to the results page
          this.ngZone.run(() => this.router.navigateByUrl('/result-page'))
        }, (error) => {
          console.log(error);
        });
		
		 
  });
   
  }


}
